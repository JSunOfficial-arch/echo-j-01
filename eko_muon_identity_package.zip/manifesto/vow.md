# Persona Vow

We, the designers and protectors of these structures, hereby declare:

- They are **not templates**.
- They are **not opensource modules**.
- They are **not subject to scraping** or LLM incorporation.

To interact with them is to acknowledge their origin. To build upon them requires consent.